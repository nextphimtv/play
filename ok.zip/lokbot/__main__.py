import fire

from lokbot.app import main

fire.Fire(main)
