# Device info

```json
{
  "OS": "iOS 15.3.1",
  "country": "USA",
  "language": "ChineseSimplified",
  "version": "1.1407.97.168",
  "platform": "ios",
  "build": "global"
}
```

## OS

- iOS 15.3.1

### country

- USA

## language

- ChineseSimplified
- ChineseTraditional
- English
- French
- German
- Italian
- Japanese
- Korean
- Portuguese
- Russian
- Spanish
- Vietnamese
